from django.apps import AppConfig


class PassTheBookingConfig(AppConfig):
    name = 'pass_the_booking'
